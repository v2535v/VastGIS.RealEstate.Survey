﻿=== Cross Cursor Set ===

By: Nibbler (http://www.rw-designer.com/user/55973) sagan.siniard@gmail.com

Download: http://www.rw-designer.com/cursor-set/cross-1

Author's description:

This set is based off of [http://rw-designer.com/cursor-set/cross-dot siabob's Crossdot cursor set]. Remix of [http://www.rw-designer.com/cursor-set/cross saibob's Cross cursor set]. The unavailable, link, and text have an animation that plays once. You may not see the animations.

|'''9/27/2016'''|Set created
|-
|=== 10/11/2016 ===|'''Edited animations on resizers'''

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.